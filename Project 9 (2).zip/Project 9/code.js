var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["34dc4902-dfdb-42bb-8b00-f31ff07ef1f7","04306277-339b-4e78-92f3-a603e62fda67"],"propsByKey":{"34dc4902-dfdb-42bb-8b00-f31ff07ef1f7":{"name":"happy","sourceUrl":null,"frameSize":{"x":768,"y":768},"frameCount":1,"looping":true,"frameDelay":12,"version":".yU4c1fAunw7nWsuYieoVqJK8DWCG1PZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":768,"y":768},"rootRelativePath":"assets/34dc4902-dfdb-42bb-8b00-f31ff07ef1f7.png"},"04306277-339b-4e78-92f3-a603e62fda67":{"name":"win","sourceUrl":"assets/v3/animations/cbGB9sCoGdA1jEj4e9F2QvEy8s0kYpgq-rFD8Q3kl80/04306277-339b-4e78-92f3-a603e62fda67.png","frameSize":{"x":1795,"y":1124},"frameCount":1,"looping":true,"frameDelay":4,"version":"0RJXDjBGPVC8hsAUe5gn5Zt6Z6hh9VFH","loadedFromSource":true,"saved":true,"sourceSize":{"x":1795,"y":1124},"rootRelativePath":"assets/v3/animations/cbGB9sCoGdA1jEj4e9F2QvEy8s0kYpgq-rFD8Q3kl80/04306277-339b-4e78-92f3-a603e62fda67.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var car1 = createSprite(100,200,15,15);
car1.shapeColor="red";
  
var car2 = createSprite(150,200,15,15);
car2.shapeColor="red";

var car3 = createSprite(200,200,15,15);
car3.shapeColor="red";

var car4 = createSprite(250,200,15,15);
car4.shapeColor="red";

var boundary1 = createSprite(300,110,700,8);
boundary1.shapeColor="black";

var boundary2 = createSprite(50,300,700,8);
boundary2.shapeColor="black";

var land1 =createSprite(10,205,50,130);
land1.shapeColor="green";

var land2 =createSprite(390,205,50,130);
land2.shapeColor="green";

var boy = createSprite(20,200,10,10);
boy.shapeColor="black";


 
    
   

drawSprites();


function draw() {
background("white");
  car1.bounceOff(boundary1);
  car1.bounceOff(boundary2);
  car2.bounceOff(boundary1);
  car2.bounceOff(boundary2);
  car3.bounceOff(boundary1);
  car3.bounceOff(boundary2);
  car4.bounceOff(boundary1);
  car4.bounceOff(boundary2);
   boy.bounceOff(boundary1);
  boy.bounceOff(boundary2);
  createEdgeSprites();
  boy.bounceOff(leftEdge);
  boy.bounceOff(rightEdge);
  boy.bounceOff(topEdge);
  boy.bounceOff(bottomEdge);
  
  boy.velocityX=0;
  boy.velocityY=0;
  
 if(keyDown("space")){
   car1.velocityX=0;
   car1.velocityY=-10;
   
 
   car2.velocityX=0;
   car2.velocityY=-12;
   
 
   car3.velocityX=0;
   car3.velocityY=-11;

   car4.velocityX=0;
   car4.velocityY=-8;
 }
 
 if(keyDown("LEFT_ARROW")){
   boy.velocityX=-5;
   boy.velocityY=0;
 }
 
 if(keyDown("RIGHT_ARROW")){
   boy.velocityX=5;
   boy.velocityY=0;
 }
 
  if(keyDown("UP_ARROW")){
   boy.velocityX=0;
   boy.velocityY=-5;
 }
 
 if(keyDown("DOWN_ARROW")){
   boy.velocityX=0;
   boy.velocityY=5;
 }
 
  
  if(boy.isTouching(car1)){
   textSize(20);
   textFont("BOSTON");
    fill("blue");
   stroke("red");
    text("Game over. press R to restart" , 50,150);
    car1.velocityY=0;
    car2.velocityY=0;
    car3.velocityY=0;
    car4.velocityY=0;
  }
  
 
  if(boy.isTouching(car1)){
   textSize(20);
   textFont("BOSTON");
    fill("blue");
   stroke("red");
    text("Game over. press R to restart" , 50,150);
    car1.velocityY=0;
    car2.velocityY=0;
    car3.velocityY=0;
    car4.velocityY=0;
  }
  
 if(boy.isTouching(car2)){
   textSize(20);
   textFont("BOSTON");
    fill("blue");
   stroke("red");
    text("Game over. press R to restart" , 50,150);
    car1.velocityY=0;
    car2.velocityY=0;
    car3.velocityY=0;
    car4.velocityY=0;
  }
  
  if(boy.isTouching(car3)){
     textSize(20);
   textFont("BOSTON");
    fill("blue");
   stroke("red");
    text("Game over. press R to restart" , 50,150);
    car1.velocityY=0;
    car2.velocityY=0;
    car3.velocityY=0;
    car4.velocityY=0;
  }
  
if(boy.isTouching(car4)){
   textSize(20);
   textFont("BOSTON");
   fill("blue");
   stroke("red");
    text("Game over. press R to restart" , 50,150);
    car1.velocityY=0;
    car2.velocityY=0;
    car3.velocityY=0;
    car4.velocityY=0;
  }

if(keyDown("r")){
 boy.x=19;  
    boy.y=203;
    car1.x=100;
    car1.y=200;
    car2.x=150; 
    car2.y=200; 
    car3.y=200;
    car3.x=200;
    car4.x=250;
    car4.y=200; 
    car1.velocityY=0;
   car2.velocityY=0;
    car3.velocityY=0;
   car4.velocityY=0;}
   
  if(boy.isTouching(land2)){
    textSize(40);
   textFont("BOSTON");
   fill("yellow");
   stroke("black");
   text("YOU WIN!",100,150);
   fill("blue");
   textSize(20);
   text("press R to restart",100,170);
   car1.x=100;
    car1.y=200;
    car2.x=150; 
    car2.y=200; 
    car3.y=200;
    car3.x=200;
    car4.x=250;
    car4.y=200; 
  }
  
  
drawSprites();


    
}



  







// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
